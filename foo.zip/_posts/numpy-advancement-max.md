---
date: 2015-08-23 15:00
category: Python
tags: [numpy, Python]
title: 'Numpy 进阶应用———最大最小值'
---

>记录下`Numpy`的一些使用技巧，这是第一篇。


###1. 求数组最大（小）值
先看代码：
```python
In [1]: import numpy as np

In [2]: a = np.array([[1, 2, -2, 10], [-3, 11, 99, -9]])

In [3]: a
Out[3]: 
array([[ 1,  2, -2, 10],
       [-3, 11, 99, -9]])

In [4]: a.max()
Out[4]: 99
```
使用`max()`函数返回数组中的最大值，最小值使用`min()`。
有时候我们可能需要知道每一行或每一列的最大（小）值，可以给`max()`添加一个额外参数：
```python
In [5]: a.max(0)
Out[5]: array([ 1, 11, 99, 10])

In [6]: a.max(1)
Out[6]: array([10, 99])
```
新的参数（`int`）给定维度，本例中是二维数组，所以最多只能取1，找到每一行的最大值并以数组形式返回，当参数为0时，找到每一列的最大值并以数组形式返回。

###2.最值的坐标
然后，我们又发现，有些时候相比于最大值和最小值我们更关心这些最值出现的未知，用`argmax()`可以帮我们完成这个任务，`argmax()`与`max()`的用法完全一样，唯一不同的是返还的是数组下标，看代码：
```python
In [8]: a.argmax()
Out[8]: 6

In [10]: a.argmin(0)
Out[10]: array([1, 0, 0, 1])

In [11]: a.argmin(1)
Out[11]: array([2, 3])
```

有一点需要注意，**默认情况下`argmax()`将以一维数组的形式返还下标**，本例中99是第7个参数，所以返回下标值6，有时候最值不是唯一的，这时候只返回第一次出现的位置，看代码：
```python
In [13]: b = np.array([1, 3, 2, -2, 3])

In [14]: b.argmax()
Out[14]: 1
```
只返回了第一个最大值的下标。

###3.思考：我需要（i, j）形式的下标
其实也很简单，`numpy`没有直接提供这个功能，我们可以稍微处理一下，以二维数组为例，自定义一个`npmax()`函数：
```python
import numpy as np

def npmax(array):
    arrayindex = array.argmax(1)
    arrayvalue = array.max(1)

    i = arrayvalue.argmax()
    j = arrayindex[i]

    return i, j
```
然后在终端进行调用：
```python
In [2]: from npmax import npmax

In [3]:  a = np.array([[1, 2, -2, 10], [-3, 11, 99, -9]])

In [4]: a
Out[4]: 
array([[ 1,  2, -2, 10],
       [-3, 11, 99, -9]])

In [5]: npmax(a)
Out[5]: (1, 2)
```