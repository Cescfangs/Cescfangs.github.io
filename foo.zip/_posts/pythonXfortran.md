---
date: 2015-04-08 14:21
status: public
tags: [Python，Fortran，Hybrid]
title: 'Python 和 Fortran的混合编程-f2py'
---

>因为导师开发的程序是Fortran，而且说实话，虽然Python有很多很好的库用来做科学计算，比如`numpy`，但是作为一种脚本语言他的运行速度还是太慢了，主流的数值计算语言一般是C++和Fortran，但是Fortran确实比C++好学很多，那么用Fortran来写Python的扩展模块吧！

刚开始上手混编，Google了一下现成的工具，决定用`numpy`自带的`f2py`模块。网上类似的教程也蛮多，有一点需要说明的是，现在的`numpy`下只有f2py.py，没有exe文件了，推荐官方的[示例](http://docs.scipy.org/doc/numpy/user/c-info.python-as-glue.html#f2py)，但是这个示例应该是针对Linux或者Mac Os下的环境，反正在win的`CMD`窗口里，直接输入
```cmd
f2py -m add add.f
```
会直接打开`\scripts`下的f2py.py那个文件，在win的CMD窗口里要运行py文件好像只能这么做：
```
python C:\Python34\Scripts\f2py.py -m add add.f
```
只要Python的环境变量对的话，就可以在当前目录下生成一个`addmodule.c`的文件，遗憾的是我还是不知道怎么用Python调用`.c`文件，虽然官方文档里说的是‘This extension module can now be compiled and used from Python just like any other extension module’

所以我决定编译成可以直接用`import`调用的模块，输入：
```
python C:\Python34\Scripts\f2py.py -c -m add add.f
```
接下来提示'Unable to find vcvarsall.bat'，按理说不应该啊，我的电脑上无论是mingw还是VS2012都装了的，Google之，好像是因为这个模块直接要找VS2008的VC编译器，根据网上的[教程](http://f.dataguru.cn/thread-160932-1-1.html)，用的方法二，因为我的是VS2012，所以改成`toolskey = "VS110COMNTOOLS" `,再次输入之前的指令，在当前工作目录生成了一个`add.pyd`文件，应该是可以了吧，赶紧试一下：

![](~/15-24-26.jpg)

总算是成功了，以此开始Python和Fortran的混编之旅吧！！