---
date: 2015-04-21 16:13
category: Python
tags: [Python，Tec]
title: Python的输入输出（二）
---

>Python自带的文件读取与输出

##全球通用的`open()`
与C、Fortran语言一样，Python操作文件的函数也是`open()`:
```python
>>> f=open('man.txt','w')
>>> f
<_io.TextIOWrapper name='man.txt' mode='w' encoding='cp936'>
```
第一个参数是文件，默认的是当前路径，我们也可以自己绝对路径，第二个参数决定了文件的操作方式，这里是写入，以下是常用的文件操作模式：
<style type="text/css">
.tg  {border-collapse:collapse;border-spacing:0;border-color:#bbb;}
.tg td{font-family:Arial, sans-serif;font-size:14px;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#594F4F;background-color:#E0FFEB;border-top-width:1px;border-bottom-width:1px;}
.tg th{font-family:Arial, sans-serif;font-size:14px;font-weight:normal;padding:10px 5px;border-style:solid;border-width:0px;overflow:hidden;word-break:normal;border-color:#bbb;color:#493F3F;background-color:#9DE0AD;border-top-width:1px;border-bottom-width:1px;}
</style>
<table class="tg">
  <tr>
    <th class="tg-031e"></th>
    <th class="tg-031e"></th>
    <th class="tg-031e"></th>
  </tr>
  <tr>
    <td class="tg-031e">'r'</td>
    <td class="tg-031e">只读</td>
    <td class="tg-031e">只能读取文件里的内容，无法进行编辑</td>
  </tr>
  <tr>
    <td class="tg-031e">'w’</td>
    <td class="tg-031e">写入</td>
    <td class="tg-031e">只能向文件里写入数据，如果存在同名文件将会清除原来数据</td>
  </tr>
  <tr>
    <td class="tg-031e">'a'</td>
    <td class="tg-031e">添加</td>
    <td class="tg-031e">内容添加到文件末尾</td>
  </tr>
  <tr>
    <td class="tg-031e">'r+'</td>
    <td class="tg-031e">读写</td>
    <td class="tg-031e">可以进行文件的读写操作</td>
  </tr>
</table>
默认情况下，文件的读取和输出都是以文本格式进行的（默认UTF-8编码），'b'会以二进制的形式对文件进行操作，'byte'是基本单位，一般来说二进制的文件会用在不包含文字的情况。
在文本模式下，读取文件时，`Python`会把不同平台的换行符号（Unix: '\n', Windows: '\r\n'）统一转换成'\n'，在写入文件时，执行相反的过程，这种模式对于文本文件的操作是没有问题的，但是有一些二进制的数据却会因此损坏，比如'exe'和'jpeg'文件，在对这些文件进行操作时一定要非常小心。

##文件操作的相关函数
假设我们的‘man.txt’文件已经有一些信息。
###f.read(size)
使用`f.read(size)`来读取文件的信息，这个函数会返回一个字符串或者一个字节(bytes object，不知道是不是这个意思)的对象，`size`是可选的，缺省时将返回所有的信息，前提是文件数据得小于你的机器一次所能读取的最大容量。到达文件末尾时，会返回一个空字符串`' '`:
```python
>>> f = open('man.txt')
>>> f.read()
'hello world\nmy name is Cesc Fangs\nI like Arsenal!!'
>>> f.read()
''
```
完成文件操作后，记得用`f.close()`关闭文件。

###f.readline()
除了用`read()`一次性读取文件内容外，还可以用`readline()`来逐行读取文件内容：
```python
>>> f = open('man.txt')
>>> f.readline()
'hello world\n'
>>> f.readline()
'my name is Cesc Fangs\n'
>>> f.readline()
'I like Arsenal!!'
>>> f.readline()
'' 
```
如果不是以新行结尾的，那么最后一行的不会返回'\n'会被忽略，但是以空行结尾的，最后会返回'\n'。
需要逐行读取文件内容时，我们一般都配合循环来干：
```python
>>> for line in f:
        print(line, end='')

hello world
my name is Cesc Fangs
I like Arsenal!!
```
用`list(f)`还可以直接直接把文件内容存到列表中来读取：
```python
>>> f.close()
>>> f=open('man.txt')
>>> list(f)
['hello world\n', 'my name is Cesc Fangs\n', 'I like Arsenal!!']
```
###f.write()
`f.write()`可以把字符串写入到文件中，同时返回字符串的长度，如果要写入其他数据，需要先转化成字符串：
```python
>>> f = open('man.txt', 'a')
>>> f.write('I am a ZJUer \n')
14
```

```python
>>> Ars = ['Ramsy', 16]
>>> s = str(Ars)
>>> f.write(s)
13
```