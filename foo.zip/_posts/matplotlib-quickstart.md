---
date: 2015-03-14 16:27
category: Python
tags: [Matplotlib,Tec,Python]
title: 'Matplotlib 学习笔记&简易教程(一)'
---

>来绘制一幅完美的三角函数图吧！

本文的源代码：[点击进入ipy notebook](http://nbviewer.ipython.org/github/Cescfangs/ipy/blob/master/Matplotlib%20%E5%AD%A6%E4%B9%A0%E7%AC%94%E8%AE%B0%26%E7%AE%80%E6%98%93%E6%95%99%E7%A8%8B.ipynb)
此文由[Cescfangs](http://likelife.info)翻译自:[Nicolas P. Rougier](http://www.labri.fr/perso/nrougier/teaching/matplotlib/)的Matplotlib教程,并作出了适当的修改。
原始出处:[http://scipy-lectures.github.io/intro/matplotlib/matplotlib.html](http://scipy-lectures.github.io/intro/matplotlib/matplotlib.html)

## 快速创建三角函数
```python
%matplotlib inline 
#要在ipy notebook里直接显示Matplotlib的输出图象，需要%inline
import matplotlib.pyplot as plt
import numpy as np
X = np.linspace(-np.pi,np.pi,256,endpoint=True)
(C,S)=np.cos(X),np.sin(X)
#这里用到了Matplotlib和numpy模块,linspace在(−π,π)之间分成共256个小段，
#并把这256个值赋予X。C,S分别是cosine和sine值（X,C,S都是numpy数组）
plt.plot(X,C)
plt.plot(X,S)
```
![](../../../images/matplotlib-quickstart/16-38-50.jpg)


## 参数修改-绘制完美的三角函数
在第一部分中我们通过`Matplotlib`和`numpy`快速创建了一个三角函数图，所采用的参数都是默认的。事实上我们可以通过相关参数（包括线型、颜色、坐标、标题、图示……）的修改使图形满足自己的需求

### 线宽和颜色
把cosine函数的颜色设置为蓝色，sine则是红色，而且线是不是看起来不够粗？
```python
fig = plt.figure(figsize=(10,6),dpi=80)
plt.plot(X, C, 'b-',lw=2.5)
plt.plot(X, S, 'r-',lw=2.5)
#这里`b-`是`color="blue",linestyle="-"`的简写形式
#`lw`=`linewidth`,两种写法都是合理的，但是`b-`这种形式明显更加简洁，也很好理解
```

![](../../../images/matplotlib-quickstart/16-45-11.jpg)

### 调整坐标轴
仔细看上面的图，总觉得不舒服，大概是因为两条曲线“顶天立地”的原因吧，要是再多留些空间会更好？试试lim:
```python
...
plt.xlim(X.min()*1.1, X.max()*1.1)
plt.ylim(C.min()*1.1, C.max()*1.1)
...
```
![](../../../images/matplotlib-quickstart/16-47-31.jpg)

### 坐标刻度改为$\pi$更合适
对于三角函数来说，1,2,3这整数值没有多大意义，倒是3.14这种能让人家一看就知道:
```python
....
plt.xticks([-np.pi, -np.pi/2, 0, np.pi/2, np.pi])
plt.yticks([-1,0,1])
...
```

![](../../../images/matplotlib-quickstart/16-51-40.jpg)
等等，3.14改成$\pi$不是更好吗？
```python
...
plt.xticks([-np.pi, -np.pi/2, 0, np.pi/2, np.pi],
           [r'$-\pi$', r'$-\pi/2$',  r'$0$', r'$\pi/2$',r'$+\pi$'])
...
```
![](../../../images/matplotlib-quickstart/16-53-29.jpg)

### 坐标轴放在中间更好看吧？
现在的坐标轴位于图象四周唉，而且X,Y的原点分散，感觉上吧坐标轴放在图象中间会更好看一点吧？
```python
...
ax=plt.gca()
ax.spines['right'].set_color('none') #先把右边和上边的边界设置为不可见
ax.spines['top'].set_color('none')
ax.xaxis.set_ticks_position('bottom')
ax.spines['bottom'].set_position(('data',0)) #然后把下边界和左边界移动到0点
ax.yaxis.set_ticks_position('left')
ax.spines['left'].set_position(('data',0))
plt.plot(X, C, 'b-',lw=2.5)
plt.plot(X, S, 'r-',lw=2.5)
#
...
```

![](../../../images/matplotlib-quickstart/16-57-28.jpg)

### 喂喂喂！我怎么知道哪条是cosine？
那就加个图例吧:
```python
...
plt.plot(X, C, 'b-',lw=2.5, label='cosine')
plt.plot(X, S, 'r-',lw=2.5, label='sine')
plt.legend(loc='upper left')
...
```

![](../../../images/matplotlib-quickstart/16-58-50.jpg)

### 特殊点注释不可少
在一幅图像中，有些关键的点要是标注出来的话，重点就不言自明了吧？2$\pi$/3如何？
```python
...
t=2*np.pi/3
plt.plot([t,t],[0,np.cos(t)], color ='blue', linewidth=2.5, linestyle="--")
plt.scatter([t,],[np.cos(t),], 50, color ='blue')
plt.annotate(r'$\sin(\frac{2\pi}{3})=\frac{\sqrt{3}}{2}$',
         xy=(t, np.sin(t)), xycoords='data',
         xytext=(+10, +30), textcoords='offset points', fontsize=16,
         arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
plt.plot([t,t],[0,np.sin(t)], color ='red', linewidth=2.5, linestyle="--")
plt.scatter([t,],[np.sin(t),], 50, color ='red')
plt.annotate(r'$\cos(\frac{2\pi}{3})=-\frac{1}{2}$',
         xy=(t, np.cos(t)), xycoords='data',
         xytext=(-90, -50), textcoords='offset points', fontsize=16,
         arrowprops=dict(arrowstyle="->", connectionstyle="arc3,rad=.2"))
...
```

![](../../../images/matplotlib-quickstart/17-00-15.jpg)

### 最后再修改一些细节
坐标轴上标记的刻度字体太小了吧！而且会被图象挡住唉！
```python
...
for label in ax.get_xticklabels() + ax.get_yticklabels():
    label.set_fontsize(16)
    label.set_bbox(dict(facecolor='w',edgecolor='None',alpha=0.4))
...
```
![](../../../images/matplotlib-quickstart/17-01-34.jpg)
>不断尝试，找到自己喜欢的风格之后，可以写个小的模块以便于之后引用。


欢迎转载，请注明出处。(๑¯∀¯๑)