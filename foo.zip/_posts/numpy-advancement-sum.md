---
date: 2016-01-30 21:30
category: Python
tags: [Python, numpy]
title: numpy进阶应用--求和
---

###1.用`numpy.sum()`根据轴求和
和上例一样，有一个4×2的数组：
```python
In [1]: import numpy as np

In [2]:  a = np.array([[1, 2, -2, 10], [-3, 11, 99, -9]])

In [3]: a
Out[3]: 
array([[ 1,  2, -2, 10],
       [-3, 11, 99, -9]])
```
不带任何参数的`np.sum()`与 Python 的内置函数 `sum()`一样对数组的所有元素求和：
```python
In [4]: np.sum(a)
Out[4]: 109
```
比普通的`sum()`强大的是，`numpy`的`sum()`可以根据数组的轴向分别进行求和，对列求和加入参数`axis=0`即可：

```python
In [5]: np.sum(a, axis=0)
Out[5]: array([-2, 13, 97,  1])
```

对行求和时`axis=1`:
```python
In [6]: np.sum(a, axis=1)
Out[6]: array([11, 98])
```