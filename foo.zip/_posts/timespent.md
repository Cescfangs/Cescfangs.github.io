---
date: 2015-08-22 23:21
category: Python
tags: [Tec, Python, C, CFD, numpy]
title: '效率对比：Numpy, C扩展、纯Python和C'
---

>只是想看看在循环中numpy，纯Python，纯C以及Python的C扩展方式下，效率到底有多少差距，这些差距带来的负面影响与Python的开发效率相权衡如何，其中纯Python, numpy将会以`for`循环和向量化运算两种方式分别讨论。

考虑到纯Python的列表支持多为数组计算比较麻烦，暂时以一维数组进行比较，循环9,999,999次，每组重复三次，运行环境为「MacBook Pro（early 2015), 2.7 GHz Intel Core i5, 8 GB 1867 MHz DDR3」：
**先上结论，C > Python 的 C 扩展 > Numpy 向量化 > 列表向量化 > 列表循环 > Numpy循环**：

###1.Python `for`循环
```python
import math

num = 9999999
x = []
y = []

for i in range(num):
    x.append(i)
    y.append(math.sin(x[i] ** 3) + math.cosh(x[i] / num))
```
三次运行时间分别是：
```python:n
[Finished in 12.3s]
[Finished in 12.7s]
[Finished in 12.3s]
```



###2.Python 列表向量化
```python
import math
num = 9999999

x = [i for i in range(num)]
y = [math.sin(x[i] ** 3) + math.cosh(x[i] / num) for i in range(num)]
```

```python:n
[Finished in 10.8s]
[Finished in 10.4s]
[Finished in 10.9s]
```


###3.Numpy 的`for`循环
```python:
import numpy as np

num = 9999999
x = np.linspace(1, num, num)

for i in range(num):
    y = np.sin(x[i] ** 3) + np.cosh(x[i] / num)

```
三次运行时间分别是：
```python:n
[Finished in 27.0s]
[Finished in 25.6s]
[Finished in 25.9s]
```

###4.Numpy 的向量运算
```python
import numpy as np

num = 9999999
x = np.linspace(1, num, num)
y = np.sin(x ** 3) + np.cosh(x / num)
```

三次运行时间分别是：
```python:n
[Finished in 1.3s]
[Finished in 1.3s]
[Finished in 1.2s]
```
###5.C循环
```C
#include <math.h>
#include <stdlib.h>


int main(int argc, char const *argv[])
{
    /* C Loop */

    int num = 9999999;
    float *x =(float*) malloc (sizeof(float) * num);
    float *y =(float*) malloc (sizeof(float) * num);
    
    for (int i = 0; i < num; i++)
    {
        x[i] = i;
        y[i] = sinf(pow(x[i],3)) + coshf(x[i] / num);
    
	}
return 0;
}
```
三次运行时间分别是：
```python:n
[Finished in 0.1s]
[Finished in 0.1s]
[Finished in 0.1s]
```
###6.Python 的 C 扩展
怎么用 C 扩展 Python？[戳这里](http://likelife.info/post/python/2015-07-27)
直接给出在 Python 中调用`cloop` 的结果：

```python
import timespent

num = 9999999
timespent.cloop(num)
```
三次所用的时间分别为
```python:n
[Finished in 0.6s]
[Finished in 0.6s]
[Finished in 0.6s]
```