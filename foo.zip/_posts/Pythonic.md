---
date: 2016-04-26 10:56
category: Python
tags: [Python，Tec]
title: '用好这几招，让你的代码洋溢着 Pythonic 的味道'
---


> 世界上有很多语言，但是我觉得 `Python` 是最有味道的，很多代码更接近于人的思考方式，既然选择了 `Python` 大法，就应该像 `Pythonist`  那样思考，写出 `Pythonic` 的代码，这篇文章介绍的都是很简单很基本的技巧，但也正是这些基础的用法使得 `Python` 变得与众不同。

#### 行内判断
求绝对值
Non-pythonic version

```python
# Non-pythonic, ugly
if x < 0:
    y = -x
else:
    y = x
```

Pythonic version

```python
#Pythonic, elegant
y = -x if x < 0 else x
```



#### 快速交换
交换两个变量的值
Non-pythonic version

```python
# Non-pythonic, ugly
temp = x
x = y
y = temp
```

Pythonic version

```python
#Pythonic, elegant
x, y = y, x
```



#### 快速生成数组
找出数组中所有大于零的数？


Non-pythonic version

```python
# Non-pythonic, ugly
x_list = [1, -1, 2, 3, -4]
y_list = []
for x in x_list:
    if x > 0:
        y_list.append(x)
```

Pythonic version

```python
#Pythonic, elegant
x_list = [1, -1, 2, 3, -4]
y_list = [x for x in x_list if x > 0]
```

不只是数组，字典也可以快速生成：

```python
#Pythonic, elegant
x_list = [1, -1, 2, 3, -4]
x_dict = {str(x): x for x in x_list}
```



#### 列表切片

> 想要获取列表中第 3-5 个元素？

Non-pythonic version

```python
# Non-pythonic, ugly
alist = [1, 2, 3, 4, 5, 6, 7]
blist = []
index = 0
for x in alist:
  if 2 < index < 6:
    blist.append(x)
  index += 1
```
Pythonic version

```python
#Pythonic, elegant
alist = [1, 2, 3, 4, 5, 6, 7]
blist = alist[3:6]

```
切片还有很多其他用法，可以戳[这里](http://www.liaoxuefeng.com/wiki/0014316089557264a6b348958f449949df42a6d3a2e542c000/001431756919644a792ee4ead724ef7afab3f7f771b04f5000)了解更多。



#### 简化判断

Non-pythonic version

```python
# Non-pythonic, ugly
if x == 1 or x == 2 or x ==3 or x == 4:
    print(x)
```

Pythonic version

```python
#Pythonic, elegant
if x in [1, 2, 3, 4]:
    print(x)
```



#### 获取序号

Non-pythonic version

```python
# Non-pythonic, ugly
i = 0
for x in x_list:
    print(i, x)
    i += 1
```

Pythonic version

```python
#Pythonic, elegant
for index, x in enumerate(x_list):
    print(index, x)
```

只要 `x_list`是可以迭代的对象就行，`enumerate()`还可以接受一个参数来指定序号的初始值：
`for index, x in enumerate(x_list, 1)` 指定起始序号为1。



##### 用`Counter`来计数
还在手动计数？
```python
# Non-pythonic, ugly
x_list = ['Ozil', 'Ramsey', 'Ozil', 'Ramsey', 'Giroud']
x_dict = {}
for x in x_list:
    if x in x_dict.keys():
        x_dict[x] += 1
    else:
        x_dict[x] = 1
print(x_dict)
```

试试`Counter`吧
```python
#Pythonic, elegant
from collections import Counter

x_list = ['Ozil', 'Ramsey', 'Ozil', 'Ramsey', 'Giroud']
x_dict = Counter(x_list)
print(x_dict)
```



##### 巧用函数工具

这里介绍两个常用的 Python 函数工具，`map`,`reduce`, 体会函数式编程的快感。

> 比如我有一大堆英文名，书写不规范，要求你整理成规范的形式（首字母大写，其余小写），这个例子来源于[廖老师的Python教程](http://www.liaoxuefeng.com/wiki/0014316089557264a6b348958f449949df42a6d3a2e542c000/0014317852443934a86aa5bb5ea47fbbd5f35282b331335000)中的习题



Non-pythonic version

```python
# Non-pythonic, ugly
name_list = ['luccy', 'BaTT', 'bOunD']
for name in name_list:
    name = name[0].upper()+ name[1:].lower()
    print(name)
```



觉得上面的代码还行，不算丑陋？让我们换个思路，用 `map`，`map()`函数接收两个参数，一个是函数，一个是`Iterable`(可迭代对象)，`map`将传入的函数依次作用到序列的每个元素，并把结果作为新的`Iterator`返回。


Pythonic version

```python
#Pythonic, elegant
def normalize(name):
    return name[0].upper() + name[1:].lower()

name_list = ['luccy', 'BaTT', 'bOunD']
print(list(map(normalize, name_list)))
```

> 再来思考这个问题，给你一个列表，求出列表中所有元素的积(还是来自于廖老师的博客)

Non-pythonic version

```python
# Non-pythonic, ugly
alist = [1, 3, 6, 10]
product = 1
for x in alist:
  sum *= x
```

对于这种问题，其实我们完全可以用`reduce`来解决，`reduce`把一个函数作用在一个序列[x1, x2, x3, ...]上，这个函数必须接收两个参数，`reduce`把结果继续和序列的下一个元素做累积计算，其效果就是：
```python
reduce(f, [x1, x2, x3, x4]) = f(f(f(x1, x2), x3), x4)
```
就让我们把这个求积的过程用`reduce()`来解决吧：
Pythonic version

```python
#Pythonic, elegant
def prod(alist):
    return reduce(multi, alist)

def multi(x, y):
    return x * y

alist = [1, 3, 6, 10]
print(prod(alist))
```

文章来自 [Cescfangs](http://www.fangs.in/post/python/pythonic) 的博客，未经授权，请不要转载。