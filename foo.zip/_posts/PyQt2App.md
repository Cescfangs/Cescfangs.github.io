---
date: 2015-07-20 15:18
category: Python
tags: Python，PyQt，Tec
title: cx_Freeze打包生成独立App
---

之前在打包成App或dmg时一直提示错误如下：
```
On Mac OS X, you might be loading two sets of Qt binaries into the same process.
Check that all plugins are compiled against the right Qt binaries. Export
DYLD_PRINT_LIBRARIES=1 and check that only one set of binaries are being loaded.
This application failed to start because it could not find or load the Qt
platform plugin "cocoa".
```
上stackoverflow查看了一下，发现了[这个问题](http://stackoverflow.com/questions/25188153/this-application-failed-to-start-because-it-could-not-find-or-load-the-qt-platfo)，根据答主的回答，这是因为打包成app后在压缩包里和系统资源库里有两个Qt资源，app不知道从哪个可以打开，答主建议在build时采用如下命令：
```
python3 setup.py bdist_mac --qt-menu-nib=/usr/local/Cellar/qt5/5.4.2/plugins/platforms/
```
后面参数确定了要调用的是App目录的qt资源，打包App成功，但是出现了一个新的问题，用该方法打包出来的App分辨率好低：
直接运行的效果：
![](~/屏幕快照 2015-07-20 15.27.47.png)

打包成独立App的效果：
![](~/屏幕快照 2015-07-20 15.28.28.png)

还是在stackoverflow上找到了[答案](http://stackoverflow.com/questions/25918008/cxfreeze-produces-fuzzy-gui-on-macbook-pro-with-retina-display)根据答主的解释，打包成App时没用确定是否按照高分辨率进行输出，即在info.plist文件里缺少了`NSHighResolutionCapable[1] `参数，所以默认渣分辨率输出了。解决方法是将`your.app/Contents/Info.plist`的内容复制出来，放到`setup.py`同一级目录下，新建一个`Info-highres.plist`（名字随意）的配置文件，粘贴`your.app/Contents/Info.plist`的内容，再加上一句(也可以在Xcode中编辑，实测更加方便直观)
```
<key>NSHighResolutionCapable</key>
<true/>
```
然后`build`时用以下命令：
```
python3 setup.py bdist_mac --custom-info-plist Info-highres.plist
```
结合之前的命令，我使用以下命令来`build`:
```
python3 setup.py bdist_mac --custom-info-plist Info-highres.plist --qt-menu-nib=/usr/local/Cellar/qt5/5.4.2/plugins/platforms/
```