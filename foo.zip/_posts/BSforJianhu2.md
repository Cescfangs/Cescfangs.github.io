---
date: 2016-05-07 23:20
category: python
tags: [Python, Tec, Stats, BeautifulSoup]
title: 'BeautifulSoup 实战（二）:获取文章详细信息'
---

> 上一篇的笔记中我们学习了如何通过 BeautifulSoup 获取简书作者的基本信息，这篇将按照同样的思路，用BeautifulSoup获取作者文章的信息（阅读次数、评论数、喜欢数和打赏次数）。

和之前一样，做好准备工作：

```python
from bs4 import BeautifulSoup
import requests
url = 'http://www.jianshu.com/users/65ed1c462691/top_articles'
header = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:36.0) Gecko/20100101 Firefox/36.0'}
response = requests.get(url, headers=header)
html = response.text
```

上面的过程把作者的主页内容存储在了`html`中，接下来就是 `BeautifulSoup` 登场的时候了：

```python
soup = BeautifulSoup(html, 'lxml')
```

我还是挑选重要的东西贴上来：

```html
...
<h4 class="title"><a href="/p/829477353cd3" target="_blank">Python 代码就该是这种味道</a></h4>
<div class="list-footer">
<a href="/p/829477353cd3" target="_blank">
          阅读 1817
</a> <a href="/p/829477353cd3#comments" target="_blank">
           · 评论 36
</a> <span> · 喜欢 82</span>
</div>
</div>
</li>
<li class="have-img">
<a class="wrap-img" href="/p/308fea12c8f8"><img alt="300" src="http://upload-images.jianshu.io/upload_images/1244841-0afbbb345c55bf48.png?imageMogr2/auto-orient/strip%7CimageView2/1/w/300/h/300"/></a>
<div>
<p class="list-top">
<a class="author-name blue-link" href="/users/65ed1c462691" target="_blank">Cescfangs</a>
<em>·</em>
<span class="time" data-shared-at="2016-04-15T18:19:52+08:00"></span>
</p>
<h4 class="title"><a href="/p/308fea12c8f8" target="_blank">PyQt5学习笔记（一）： 来创建第一个PyQt应用吧！</a></h4>
<div class="list-footer">
<a href="/p/308fea12c8f8" target="_blank">
          阅读 398
</a> <a href="/p/308fea12c8f8#comments" target="_blank">
           · 评论 3
</a> <span> · 喜欢 15</span>
</div>
...
```

发现了什么？所有文章的题目都是在`<h4>`标签里，而文章的数据信息都是在`<div class="list-footer">`标签里，我们先把文章题目找出来：

```python
h4 = soup.find_all('h4')
```

结果是这样子的：

```python
[<h4 class="title"><a href="/p/829477353cd3" target="_blank">Python 代码就该是这种味道</a></h4>,
 <h4 class="title"><a href="/p/308fea12c8f8" target="_blank">PyQt5学习笔记（一）： 来创建第一个PyQt应用吧！</a></h4>,
 <h4 class="title"><a href="/p/7fbecf5255f0" target="_blank">Python-matplotlib：快速入门教程</a></h4>,
 <h4 class="title"><a href="/p/09994c9d8489" target="_blank">混合编程：用 C 语言来扩展 Python 大法吧！</a></h4>,
 <h4 class="title"><a href="/p/d0e4f2f6e72e" target="_blank"> PyQt5学习笔记（八）：工具栏、菜单栏、状态栏整合</a></h4>,
 <h4 class="title"><a href="/p/8fc44cea9bd8" target="_blank">PyQt5学习笔记（五）：弹出对话框请求确认</a></h4>,
 <h4 class="title"><a href="/p/cd190dbf0435" target="_blank">可能会有用的Clion技巧—— Mac篇</a></h4>,
 <h4 class="title"><a href="/p/c0b42c36aff4" target="_blank">PyQt5学习笔记（六）：创建菜单栏</a></h4>,
 <h4 class="title"><a href="/p/55aec1eaa35e" target="_blank">PyQt5学习笔记（四）：退出按钮</a></h4>]
```

通过列表推导简单处理一下数据：

```python
h4_title = [item.string for item in h4]
h4_title

'''
['Python 代码就该是这种味道',
 'PyQt5学习笔记（一）： 来创建第一个PyQt应用吧！',
 'Python-matplotlib：快速入门教程',
 '混合编程：用 C 语言来扩展 Python 大法吧！',
 ' PyQt5学习笔记（八）：工具栏、菜单栏、状态栏整合',
 'PyQt5学习笔记（五）：弹出对话框请求确认',
 '可能会有用的Clion技巧—— Mac篇',
 'PyQt5学习笔记（六）：创建菜单栏',
 'PyQt5学习笔记（四）：退出按钮']
 '''
```

文章的题目已经提取好了，接下来去寻找所有的`<div class="list-footer">`标签，和上面的方法一样：

```python
list_footer = soup.find_all('div', class_='list-footer')
list_footer
''''内容稍多，贴一部分
[<div class="list-footer">
 <a href="/p/829477353cd3" target="_blank">
           阅读 1817
 </a> <a href="/p/829477353cd3#comments" target="_blank">
            · 评论 36
 </a> <span> · 喜欢 82</span>
 </div>, <div class="list-footer">
 <a href="/p/308fea12c8f8" target="_blank">
           阅读 398
 </a> <a href="/p/308fea12c8f8#comments" target="_blank">
            · 评论 3
 </a> <span> · 喜欢 15</span>
 </div>, <div class="list-footer">
 <a href="/p/7fbecf5255f0" target="_blank">
           阅读 361
 </a> <a href="/p/7fbecf5255f0#comments" target="_blank">
            · 评论 4
 </a> <span> · 喜欢 13</span>
 </div>, <div class="list-footer">
 <a href="/p/09994c9d8489" target="_blank">
           阅读 274
 </a> <a href="/p/09994c9d8489#comments" target="_blank">
            · 评论 3
 </a> <span> · 喜欢 10</span>
 <span> · 打赏 1</span>
 </div>,
 ...]''''
```

情况比之前的稍微复杂一点，阅读和评论在`<a>`标签里，而喜欢和打赏却在`<span>`标签里，还好BeautifulSoup的find_all可以添加多个参数：

```python
list_footer_list = [item.find_all(['a','span']) for item in list_footer]
list_footer_list
'''
[[<a href="/p/829477353cd3" target="_blank">
            阅读 1817
  </a>, <a href="/p/829477353cd3#comments" target="_blank">
             · 评论 36
  </a>, <span> · 喜欢 82</span>], [<a href="/p/308fea12c8f8" target="_blank">
            阅读 398
  </a>, <a href="/p/308fea12c8f8#comments" target="_blank">
             · 评论 3
  </a>, <span> · 喜欢 15</span>], [<a href="/p/7fbecf5255f0" target="_blank">
            阅读 361
  </a>, <a href="/p/7fbecf5255f0#comments" target="_blank">
             · 评论 4
  </a>, <span> · 喜欢 13</span>], [<a href="/p/09994c9d8489" target="_blank">
            阅读 274
  </a>, <a href="/p/09994c9d8489#comments" target="_blank">
             · 评论 3
  </a>, <span> · 喜欢 10</span>, <span> · 打赏 1</span>], [<a href="/p/d0e4f2f6e72e" target="_blank">
            阅读 167
  </a>,
  <a href="/p/d0e4f2f6e72e#comments" target="_blank">
             · 评论 4
  </a>,
  <span> · 喜欢 6</span>], [<a href="/p/8fc44cea9bd8" target="_blank">
            阅读 114
  </a>, <a href="/p/8fc44cea9bd8#comments" target="_blank">
             · 评论 2
  </a>, <span> · 喜欢 5</span>], [<a href="/p/cd190dbf0435" target="_blank">
            阅读 1057
  </a>, <a href="/p/cd190dbf0435#comments" target="_blank">
             · 评论 4
  </a>, <span> · 喜欢 5</span>], [<a href="/p/c0b42c36aff4" target="_blank">
            阅读 133
  </a>, <a href="/p/c0b42c36aff4#comments" target="_blank">
             · 评论 3
  </a>, <span> · 喜欢 4</span>], [<a href="/p/55aec1eaa35e" target="_blank">
            阅读 148
  </a>, <a href="/p/55aec1eaa35e#comments" target="_blank">
             · 评论 4
  </a>, <span> · 喜欢 4</span>]]
'''
```

BeautifulSoup提供的`string`属性可以返回标签的内容比如‘阅读 167’，在此基础上我们还是需要处理一下字符串，只保留我们想要的数字，我们先定义一个函数去掉字符串里的非数字内容：

```python
def trans2numbers(string):
    return int(''.join(a for a in string.strip() if a.isdigit()))
```

还需要一个新的函数来处理`list_footer_list` ：

```python
def article_status(article_list):
    result = []
    for item in article_list:
        result.append(trans2numbers(item.string))
    
    return result
```

有了上面的两个函数，就可以进行列表推导来构造新的列表了：

```python
article_status_list = [article_status(item) for item in list_footer_list]
article_status_list
'''
[[1817, 36, 82],
 [398, 3, 15],
 [361, 4, 13],
 [274, 3, 10, 1],
 [167, 4, 6],
 [114, 2, 5],
 [1057, 4, 5],
 [133, 3, 4],
 [148, 4, 4]]
'''
```

构造了一个二维的列表，每一个列表第一个数字是阅读数量，第二个是评论数，第三个是喜欢的数量，如果文章被打赏的话还会有一个打赏的数字，然后我们把数字和文章的题目对应起来：

```python
articles = []
for title, status in zip(h4_title, article_status_list):
    articles.append([title, status])
    
articles
'''
[['Python 代码就该是这种味道', [1819, 36, 82]],
 ['PyQt5学习笔记（一）： 来创建第一个PyQt应用吧！', [400, 3, 15]],
 ['Python-matplotlib：快速入门教程', [362, 4, 13]],
 ['混合编程：用 C 语言来扩展 Python 大法吧！', [275, 3, 10, 1]],
 [' PyQt5学习笔记（八）：工具栏、菜单栏、状态栏整合', [169, 4, 6]],
 ['PyQt5学习笔记（五）：弹出对话框请求确认', [116, 2, 5]],
 ['可能会有用的Clion技巧—— Mac篇', [1064, 4, 5]],
 ['PyQt5学习笔记（六）：创建菜单栏', [135, 3, 4]],
 ['PyQt5学习笔记（四）：退出按钮', [149, 4, 4]]]
'''
```

大功告成!!!

不知道细心如你有没有发现以上得到的文章只有九篇，但是我明明写了20篇啊啊啊！嗯嗯，其实主页的内容是分次加载的，并不会一次性把你所有的文章加载，而是采用下拉刷新的模式加载第二页第三页的内容，解决这个并不难，找到其他文章展示页的地址就行了。