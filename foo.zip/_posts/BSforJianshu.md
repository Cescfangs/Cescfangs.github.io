---
date: 2016-05-06 15:31
category: Python
tags: [Python, Tec, Stats, BeautifulSoup]
title: 'BeautifulSoup 实战（一）：获取简书作者信息'
---

> `BeautifulSoup` 是`Python` 非常好用的一个库，可以用它来方便地解析网页内容，获取我们需要的数据，几乎是`Python` 爬虫居家旅行必备的库，这个系列的文章会记录下用`BeautifulSoup`获取简书数据的过程，但不会详细介绍 `BeautifulSoup` 的用法，有需要的同学可以参见官方文档。文章来自 [Cescfangs](http://www.fangs.in/post/python/bsforjianshu) 的博客，未经授权，请不要转载。

第一篇介绍怎么用 `BeautifulSoup` 获取简书作者的基本信息，包括文章数量、粉丝数量、获得的喜欢等，先把需要的库导进来：

```python
import requests
from bs4 import BeautifulSoup
```

打开你的简书主页地址，复制到`url`:

```python
url = 'http://www.jianshu.com/users/65ed1c462691/top_articles'
```

你会发现所有用户主页的域名都是`'http://www.jianshu.com/users/` + `ID` 这个`ID`每个人都不同，接下来我们会用到 `requests` ，当然你也可以直接用 `Python` 的 `urlib` 来获取网页内容，我选择requests是因为它的语法更简单，用requests 请求数据之前先伪装成浏览器，否则很可能被服务器拒绝：

```python
header = {'User-Agent': 'Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:36.0) Gecko/20100101 Firefox/36.0'}
response = requests.get(url, headers=header)
html = response.text
```

然后把得到的 `html` 传入到 `BeautifulSoup` 进行解析，这里用了 `Python` 自带的 `html.parser`（建议使用`lxml`）

```python
soup = BeautifulSoup(html, 'html.parser')
```

网页内容较多，我贴一部分上来：

```html
<title>Cescfangs - 简书</title>
<meta content="authenticity_token" name="csrf-param"/>
...
<div class="user-stats">
<ul class="clearfix">
<li>
<a href="/users/65ed1c462691/subscriptions"><b>11</b><span>关注</span></a>
</li>
<li>
<a href="/users/65ed1c462691/followers"><b>104</b><span>粉丝</span></a>
</li>
<br>
<li>
<a href="/users/65ed1c462691"><b>19</b><span>文章</span></a>
</li>
<li>
<a><b>15315</b><span>字数</span></a>
</li>
<li>
<a><b>166</b><span>收获喜欢</span></a>
</li>
</br></ul>
</div>
</div>
```

粗略一看，发现我们作者的基本信息（文章数、收到的喜欢等）都包含在`<ul class="clearfix">`这个标签内，让我们用 `BeautifulSoup` 找到这个标签：

```python
author_info = soup.find_all('ul', class_='clearfix')
```

`author_info` 的内容如下：

```python
[<ul class="clearfix">
 <li>
 <a href="/users/65ed1c462691/subscriptions"><b>11</b><span>关注</span></a>
 </li>
 <li>
 <a href="/users/65ed1c462691/followers"><b>104</b><span>粉丝</span></a>
 </li>
 <br>
 <li>
 <a href="/users/65ed1c462691"><b>19</b><span>文章</span></a>
 </li>
 <li>
 <a><b>15315</b><span>字数</span></a>
 </li>
 <li>
 <a><b>166</b><span>收获喜欢</span></a>
 </li>
 </br></ul>]
```

返回的结果是一个可迭代对象，其实只有一个元素:

```python
info = author_info[0]
```

现在变成了这样：

```html
<ul class="clearfix">
<li>
<a href="/users/65ed1c462691/subscriptions"><b>11</b><span>关注</span></a>
</li>
<li>
<a href="/users/65ed1c462691/followers"><b>104</b><span>粉丝</span></a>
</li>
<br>
<li>
<a href="/users/65ed1c462691"><b>19</b><span>文章</span></a>
</li>
<li>
<a><b>15315</b><span>字数</span></a>
</li>
<li>
<a><b>166</b><span>收获喜欢</span></a>
</li>
</br></ul>
```

我们获得了一个新的 `BeautifulSoup` 标签对象，再观察我们需要的数字都在这个对象的 `b` 标签里，再把它们找出来:

```python
numbers = info.find_all('b')
numbers
#[<b>11</b>, <b>104</b>, <b>19</b>, <b>15315</b>, <b>166</b>]
```

嗯嗯，距离成功很近了，处理一下数据，保留我们需要的数字就够了:

```python
number_list = [int(item.string) for item in numbers]
```

number_list 是这样子的：

```python
[11, 104, 19, 15315, 166]
```

好像还漏了作者的名字，名字就藏在 `title` 标签里，这里用了 `find`，它只返回第一个符合要求的结果:

```python
name = soup.find('title')
name.string
#'Cescfangs - 简书'
```

把不要的后缀去掉：

```python
author_name = name.string[:-5]
author_name
#'Cescfangs'
```

嘿嘿嘿，写个简单的函数整合一下我们获得的数据：

```python
def author(name, number_list):
    author_dict = {}
    author_dict['name'] = name
    author_dict['following'] = number_list[0]
    author_dict['fans'] = number_list[1]
    author_dict['articles'] = number_list[2]
    author_dict['words'] = number_list[3]
    author_dict['likes'] = number_list[4]
    
    return author_dict
```

试试看：

```python
cesc = author(author_name, number_list)
cesc
'''
{'articles': 19,
 'fans': 104,
 'following': 11,
 'likes': 166,
 'name': 'Cescfangs',
 'words': 15315}''''
```

再写个函数方便输出:

```python
def print_author(author_dict):
    print(author_dict['name'], '有', author_dict['fans'], '个粉丝，写了', 		  author_dict['articles'],
          '篇文章，码了', author_dict['words'], '个字，\n收割了', author_dict['likes'],
          '颗喜欢， 他悄悄关注了', author_dict['following'], '人~~~')
    
print_author(cesc)
#Cescfangs 有 104 个粉丝，写了 19 篇文章，码了 15315 个字，
#收割了 166 颗喜欢， 他悄悄关注了 11 人~~~
```

本文的源码（Jupyter Notebook）戳[这里](http://nbviewer.jupyter.org/github/cescfangs/ipy/blob/master/BS_1_Jianshu.ipynb)